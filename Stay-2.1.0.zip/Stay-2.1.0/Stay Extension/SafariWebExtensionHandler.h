//
//  SafariWebExtensionHandler.h
//  Stay Extension
//
//  Created by ris on 2021/10/15.
//

#import <Foundation/Foundation.h>

@interface SafariWebExtensionHandler : NSObject <NSExtensionRequestHandling>

@end
