//
//  FCApp.h
//  FastClip-iOS
//
//  Created by ris on 2022/2/8.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FCApp : NSObject
@property (readonly, class) UIWindow *keyWindow;
@end

NS_ASSUME_NONNULL_END
