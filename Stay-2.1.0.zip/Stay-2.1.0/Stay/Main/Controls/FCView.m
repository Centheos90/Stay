//
//  FCView.m
//  FastClip-iOS
//
//  Created by ris on 2022/2/7.
//

#import "FCView.h"

@interface FCView()

@end

@implementation FCView

@end
