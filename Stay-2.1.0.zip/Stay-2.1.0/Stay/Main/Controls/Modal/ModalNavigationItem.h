//
//  ModalNavigationItem.h
//  FastClip-iOS
//
//  Created by ris on 2022/2/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ModalNavigationItem : NSObject

@end

NS_ASSUME_NONNULL_END
