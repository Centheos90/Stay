//
//  ModalNavigationItem.m
//  FastClip-iOS
//
//  Created by ris on 2022/2/7.
//

#import "ModalNavigationItem.h"

@implementation ModalNavigationItem

@end
