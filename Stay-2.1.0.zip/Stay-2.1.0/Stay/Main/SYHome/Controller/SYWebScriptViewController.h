//
//  SYWebScriptViewController.h
//  Stay
//
//  Created by zly on 2022/4/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SYWebScriptViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
