//
//  JSDetailEntity.m
//  Stay
//
//  Created by zly on 2021/11/10.
//

#import "JSDetailEntity.h"

@implementation JSDetailEntity

@end
