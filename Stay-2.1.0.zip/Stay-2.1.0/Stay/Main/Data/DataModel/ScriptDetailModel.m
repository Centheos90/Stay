//
//  ScriptDetailModel.m
//  Stay
//
//  Created by zly on 2021/11/22.
//

#import "ScriptDetailModel.h"

@implementation ScriptDetailModel

@end
