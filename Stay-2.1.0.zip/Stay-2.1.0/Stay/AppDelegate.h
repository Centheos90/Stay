//
//  AppDelegate.h
//  Stay
//
//  Created by ris on 2021/10/15.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@end
