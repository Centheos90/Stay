//
//  SceneDelegate.h
//  Stay
//
//  Created by ris on 2021/10/15.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end
