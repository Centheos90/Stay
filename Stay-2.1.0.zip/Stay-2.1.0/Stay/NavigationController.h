//
//  NavigationController.h
//  Stay
//
//  Created by ris on 2021/10/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
